export default {
  green: '\x1b[32m',
  red: '\x1b[31m',
  yellow: '\x1b[33m',
  reset: '\x1b[0m',
  taskTitle: '\x1b[42m\x1b[30m',
};
