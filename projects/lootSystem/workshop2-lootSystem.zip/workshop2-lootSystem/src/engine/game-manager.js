/* eslint-disable quotes */
import { itemRarity } from '../common/item-rarity.js';
import { Hero } from '../models/hero.js';
import { Item } from '../models/items/item.js';
import { Stat } from '../models/stat.js';

export class GameManager {

  static #MAGIC_RARITY = 20;
  static #RARE_RARITY = 7;
  static #UNIQUE_RARITY = 1;

  static createHero(name) {
    return new Hero(name);
  }

  static dropRandomItem() {

    const randomMap = new Map();

    const makeRandomName = (length) => {
      let result = '';
      const characters = "abcdefghijklmnopqrstuvwxyz' ";
      const charactersLength = characters.length;
      for ( let i = 0; i < length; i++ ) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
      }
      return result
        .split(' ')
        .map((el)=> {
          if (el.length === 1) return el.toUpperCase();
          if (!el) return '';
          if (el[0] === "'") return el[1].toUpperCase() + el.slice(2);
          return el[0].toUpperCase() + el.slice(1);
        })
        .join(' ');
    };

    const makeRandomInt = (min, max) => {
      return Math.floor(Math.random() * (max - min + 1) + min);
    };

    const randomRarity = this.#calculateRarity();
    const randomName = makeRandomName(makeRandomInt(6, 11));
    const randomType = makeRandomInt(1, 3);

    for (let i = 0; i < randomRarity; i++) {
      let randomStatType = makeRandomInt(1, 6);
      if (randomRarity > 1) {
        for (let j = 0; j < 1; j++) {
          if (randomMap.has(randomStatType)) {
            randomStatType = makeRandomInt(1, 6);
            j--;
          }
        }
      }
      const randomValue = makeRandomInt(1, 100);
      const randomStatApplyType = makeRandomInt(1, 2);
      randomMap.set(randomStatType, new Stat(randomStatType, randomValue, randomStatApplyType));
    }

    return new Item(randomName, randomType, randomRarity, randomMap);
  }

  static #calculateRarity() {
    const chance = Math.floor(Math.random() * 100);

    if (chance <= GameManager.#UNIQUE_RARITY) {
      return itemRarity.UNIQUE;
    }

    if (chance <= GameManager.#RARE_RARITY) {
      return itemRarity.RARE;
    }

    if (chance <= GameManager.#MAGIC_RARITY) {
      return itemRarity.MAGIC;
    }

    return itemRarity.COMMON;
  }

}


