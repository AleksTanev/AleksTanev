import { statApplyType } from '../common/stat-apply-type.js';
import { statType } from '../common/stat-type.js';

export class Stat {
  #applyType;
  #value;
  #type;

  /**
   * @param {number} type statType value
   * @param {number} value positive number
   * @param {number} applyType applyType value
   */
  constructor(type, value, applyType) {

    if (!Object.values(statType).includes(type)) throw new Error('Not a valid statType value!');

    if (value <= 0) throw new Error('Passed value should be a positive number!');

    if (!Object.values(statApplyType).includes(applyType)) throw new Error('Not a valid statApplyType value!');

    this.#type = type;

    this.#value = value;

    this.#applyType = applyType;
  }

  get value() {
    return this.#value;
  }

  get type() {
    return this.#type;
  }

  get applyType() {
    return this.#applyType;
  }

  /**
   * Converts stat value based on statApplyType to number.
   * @param {number} stat default is 0
   * @return {number} number
   */
  apply(stat=0) {

    if (this.applyType === statApplyType.FLAT) return stat + this.value;
    return stat*(1+this.value/100) || this.value;
  }
}
