import { makeSymmetricalEnum } from './make-symmetrical-enum.js';

export const statApplyType = {
  FLAT: 1,
  PERCENTAGE: 2,
};

makeSymmetricalEnum(statApplyType);
