export default {
  noSame: 'no-same',
};
