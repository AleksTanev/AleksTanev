import { itemRarity } from './common/item-rarity.js';
import { itemType } from './common/item-type.js';
import { statType } from './common/stat-type.js';
import { statApplyType } from './common/stat-apply-type.js';
import { GameManager } from './engine/game-manager.js';
import { Item } from './models/items/item.js';
import { Stat } from './models/stat.js';
// import { Hero } from './models/hero.js';

// Create an armor
const armorStats = new Map();

armorStats.set(statType.HEALTH, new Stat(statType.HEALTH, 25, statApplyType.FLAT));
armorStats.set(statType.INTELLIGENCE, new Stat(statType.INTELLIGENCE, 20, statApplyType.PERCENTAGE));
armorStats.set(statType.CRIT_CHANCE, new Stat(statType.CRIT_CHANCE, 20, statApplyType.FLAT));

const armor = new Item(`Tyrael's Might`, itemType.ARMOR, itemRarity.COMMON, armorStats);

// Create a weapon
const weaponStats = new Map();

weaponStats.set(statType.HEALTH, new Stat(statType.HEALTH, 25, statApplyType.FLAT));
weaponStats.set(statType.STRENGTH, new Stat(statType.STRENGTH, 40, statApplyType.FLAT));
weaponStats.set(statType.CRIT_DAMAGE, new Stat(statType.CRIT_DAMAGE, 300, statApplyType.PERCENTAGE));
const weapon = new Item('Dragnipur', itemType.WEAPON, itemRarity.COMMON, weaponStats);

// Create an amulet
const amuletStats = new Map();

amuletStats.set(statType.HEALTH, new Stat(statType.HEALTH, 50, statApplyType.PERCENTAGE));
amuletStats.set(statType.DAMAGE, new Stat(statType.DAMAGE, 10, statApplyType.PERCENTAGE));
const amulet = new Item('Astramentis', itemType.AMULET, itemRarity.COMMON, amuletStats);

const hero = GameManager.createHero('Madawc');

console.log(armor.printItemInfo());

hero.equip(armor);
hero.equip(weapon);
hero.equip(amulet);

console.log(hero.printHeroInfo());

console.log('*** Equipping Decard Cain Test ***');

const epicItem = GameManager.dropRandomItem();
console.log(epicItem.printItemInfo());

const epicItem2 = GameManager.dropRandomItem();
console.log(epicItem2.printItemInfo());

const epicItem3 = GameManager.dropRandomItem();
console.log(epicItem3.printItemInfo());


const theDecard = GameManager.createHero('Decard Cain');

theDecard.equip(epicItem);
theDecard.equip(epicItem2);
theDecard.equip(epicItem3);

console.log(theDecard.printHeroInfo());
// "Stay a while, ..."

