import { makeSymmetricalEnum } from './make-symmetrical-enum.js';

export const itemRarity = {
  COMMON: 1,
  MAGIC: 2,
  RARE: 3,
  UNIQUE: 4,
};

makeSymmetricalEnum(itemRarity);
