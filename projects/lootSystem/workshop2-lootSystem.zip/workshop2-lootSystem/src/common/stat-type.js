import { makeSymmetricalEnum } from './make-symmetrical-enum.js';

export const statType = {
  DAMAGE: 1,
  HEALTH: 2,
  INTELLIGENCE: 3,
  STRENGTH: 4,
  CRIT_CHANCE: 5,
  CRIT_DAMAGE: 6,
};

makeSymmetricalEnum(statType);
