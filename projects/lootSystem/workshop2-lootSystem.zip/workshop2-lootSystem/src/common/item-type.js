import { makeSymmetricalEnum } from './make-symmetrical-enum.js';

export const itemType = {
  ARMOR: 1,
  WEAPON: 2,
  AMULET: 3,
};

makeSymmetricalEnum(itemType);
