/* eslint-disable indent */
import { itemRarity } from '../../common/item-rarity.js';
import { itemType } from '../../common/item-type.js';
import { statType } from '../../common/stat-type.js';
import { statApplyType } from '../../common/stat-apply-type.js';


export class Item {

  #name;
  #rarity;
  #type;
  #stats;

  /**
   * @param {string} name string name
   * @param {number} type statType value
   * @param {number} rarity itemRarity value
   * @param {Map} stats instance of Map
   */
  constructor(name, type, rarity, stats) {
    if (typeof name !== 'string' || name.length < 2 || name.length > 100) {
      throw new Error('Invalid name!');
    }

    if (itemType[itemType[type]] === undefined) {
      throw new Error('Invalid item type!');
    }

    if (itemRarity[itemRarity[rarity]] === undefined) {
      throw new Error('Invalid item rarity!');
    }

    if (!(stats instanceof Map)) {
      throw new Error('Invalid instance of Map!');
    }

    this.#name = name;
    this.#rarity = rarity;
    this.#type = type;
    this.#stats = stats;
  }

  get name() {
    return this.#name;
  }

  get type() {
    return this.#type;
  }

  get rarity() {
    return this.#rarity;
  }

  get stats() {
    return new Map(this.#stats);
  }

  printItemInfo() {
    let baseStr = `
  Name: ${this.name}
  Type: ${itemType[this.type]}
  Rarity: ${itemRarity[this.rarity]}
  ---Stats---
  `;
    for (const [key, value] of this.stats) {
      baseStr += `${statType[key]}: +${value.apply() + ((value.applyType === statApplyType.FLAT) ? '' : `%`)}
  `;
    }

    return baseStr;
  }

}


