/* eslint-disable indent */
import { itemType } from '../common/item-type.js';
import { statApplyType } from '../common/stat-apply-type.js';
import { statType } from '../common/stat-type.js';
import { Item } from './items/item.js';

export class Hero {

  #name;
  #baseHealth = 100;
  #baseStrength = 25;
  #baseIntelligence = 20;
  #baseDefence = 20;
  #baseDamage = 10;
  #baseCritChance = 0;

  #armor = null;
  #weapon = null;
  #amulet = null;

  constructor(name) {
    if (typeof name !== 'string' || name.length < 2 || name.length > 100) {
      throw new Error('Invalid name!');
    }

    this.#name = name;
  }

  equip(item) {
    if (!(item instanceof Item)) {
      throw new Error('Invalid item!');
    }

    switch (item.type) {
      case itemType.ARMOR:
        this.#armor = item;
        break;
      case itemType.WEAPON:
        this.#weapon = item;
        break;
      case itemType.AMULET:
        this.#amulet = item;
        break;
    }
  }

  get name() {
    return this.#name;
  }

  get strength() {
    const [strength, strengthMultiplier] = this.#calculateFlatAndMultiplier(this.#baseStrength, statType.STRENGTH);

    return strength * strengthMultiplier;
  }

  get intelligence() {
    const [intelligence, intelligenceMultiplier] = this.#calculateFlatAndMultiplier(this.#baseIntelligence, statType.INTELLIGENCE);

    return intelligence * intelligenceMultiplier;
  }

  get critChance() {
    const [chance, chanceMultiplier] = this.#calculateFlatAndMultiplier(this.#baseCritChance, statType.CRIT_CHANCE);

    return chance * chanceMultiplier;
  }

  get critDamage() {
    const [crit, critMultiplier] = this.#calculateFlatAndMultiplier(this.#baseCritChance, statType.CRIT_DAMAGE);

    if (crit === 0) {
      return this.damage * critMultiplier;
    }

    return this.damage * crit * critMultiplier;
  }

  get damage() {
    const [damage, damageMultiplier] = this.#calculateFlatAndMultiplier(this.#baseDamage, statType.DAMAGE);

    return damage * damageMultiplier + this.strength * 0.5 + this.intelligence + 0.2;
  }

  get health() {
    const [health, healthMultiplier] = this.#calculateFlatAndMultiplier(this.#baseHealth, statType.HEALTH);

    return health * healthMultiplier;
  }

  get defense() {
    return this.#baseDefence + 2 * this.strength;
  }

  printHeroInfo() {
    return `
Name: ${this.name}
Health: ${this.health.toFixed(2)}
Defense: ${this.defense.toFixed(2)}
Damage: ${this.damage.toFixed(2)}
Strength: ${this.strength.toFixed(2)}
Intelligence: ${this.intelligence.toFixed(2)}
Crit chance: ${this.critChance.toFixed(2)}
Crit damage: ${this.critDamage.toFixed(2)}
    `;
  }

  #calculateFlatAndMultiplier(value, type) {
    let multiplier = 1;

    for (const item of [this.#amulet, this.#armor, this.#weapon]) {
      if (item !== null) {
        for (const [key, valueMap] of item.stats) {

          if (key === type) {
            if (valueMap.applyType === statApplyType.FLAT) {
              value = valueMap.apply(value);
            } else {
              multiplier = valueMap.apply(multiplier);
            }
          }
        }
      }
    }
    return [value, multiplier];
  }
}
